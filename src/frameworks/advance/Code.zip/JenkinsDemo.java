package com.frameworks.advance;

import org.testng.annotations.Test;

public class JenkinsDemo {

	@Test
	public void test1(){
		System.out.println("This is test case 1");
	}
	
	@Test
	public void test2(){
		System.out.println("This is test case 2");
	}
	
	@Test
	public void test3(){
		System.out.println("This is test case 3");
	}
	
	@Test
	public void test4(){
		System.out.println("This is test case 4");
	}
	
	@Test
	public void test5(){
		System.out.println("This is test case 5");
	}
}
